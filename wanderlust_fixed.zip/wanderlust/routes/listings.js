const express = require("express");
const router = express.Router({ mergeParams: true });

const listingsController = require("../controllers/listingsController");
const { isLoggedIn } = require("../middleware/isLoggedIn");
const { isAuthor } = require("../middleware/isAuthor");
const { validateListing } = require("../middleware/validateListing");
const catchAsync = require("../middleware/catchAsync");

const multer = require("multer");
const { storage } = require("../utils/cloudinary");
const upload = multer({ storage });

const reviewRouter = require("./reviews");

// INDEX - ALL LISTINGS
router.get("/", catchAsync(listingsController.index));

// MY LISTINGS
router.get("/my-listings", isLoggedIn, catchAsync(listingsController.myListings));

// NEW LISTING FORM
router.get("/new", isLoggedIn, listingsController.newForm);

// CREATE LISTING
router.post(
  "/",
  isLoggedIn,
  upload.array("images", 10),
  validateListing,
  catchAsync(listingsController.createListing)
);

// NESTED REVIEW ROUTES
router.use("/:id/reviews", reviewRouter);

// SHOW + UPDATE + DELETE
router
  .route("/:id")
  .get(catchAsync(listingsController.show))
  .put(
    isLoggedIn,
    isAuthor,
    upload.array("images", 10),
    validateListing,
    catchAsync(listingsController.updateListing)
  )
  .delete(
    isLoggedIn,
    isAuthor,
    catchAsync(listingsController.deleteListing)
  );

// EDIT FORM
router.get(
  "/:id/edit",
  isLoggedIn,
  isAuthor,
  catchAsync(listingsController.editForm)
);

module.exports = router;

