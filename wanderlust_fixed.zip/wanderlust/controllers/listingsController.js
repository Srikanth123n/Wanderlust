const Listing = require("../models/Listing");
const Review = require("../models/Review");
const { getCoordinates } = require("../utils/geocoder");

// GET ALL LISTINGS
module.exports.index = async (req, res) => {
  const category = req.query.category;
  const filter = category ? { category } : {};
  const listings = await Listing.find(filter);
  res.render("listings/index", {
    listings,
    category
  });
};

// NEW FORM
module.exports.newForm = (req, res) => {
  res.render("listings/new");
};

// CREATE LISTING
module.exports.createListing = async (req, res) => {
  const listing = new Listing(req.body.listing);
  listing.author = req.user._id;

  // Add images if uploaded
  if (req.files && req.files.length > 0) {
    listing.images = req.files.map(f => ({
      url: f.path,
      filename: f.filename
    }));
  }

  // Geocode location to get coordinates
  const locationString = `${listing.location}, ${listing.country}`;
  listing.geometry = await getCoordinates(locationString);

  await listing.save();
  req.flash("success", "Listing created successfully!");
  res.redirect(`/listings/${listing._id}`);
};

// SHOW LISTING
module.exports.show = async (req, res) => {
  const listing = await Listing.findById(req.params.id)
    .populate("author")
    .populate({
      path: "reviews",
      populate: { path: "author" }
    });

  if (!listing) {
    req.flash("error", "Listing not found");
    return res.redirect("/listings");
  }

  res.render("listings/show", { listing });
};

// EDIT FORM
module.exports.editForm = async (req, res) => {
  const listing = await Listing.findById(req.params.id);
  res.render("listings/edit", { listing });
};

// UPDATE LISTING
module.exports.updateListing = async (req, res) => {
  const listing = await Listing.findByIdAndUpdate(
    req.params.id,
    req.body.listing,
    { new: true }
  );

  // Add new uploaded images
  if (req.files && req.files.length > 0) {
    const newImgs = req.files.map(f => ({
      url: f.path,
      filename: f.filename
    }));
    listing.images.push(...newImgs);
  }

  // Re-geocode if location changed
  if (req.body.listing.location || req.body.listing.country) {
    const locationString = `${listing.location}, ${listing.country}`;
    listing.geometry = await getCoordinates(locationString);
  }

  await listing.save();
  req.flash("success", "Listing updated successfully!");
  res.redirect(`/listings/${listing._id}`);
};

// DELETE LISTING
module.exports.deleteListing = async (req, res) => {
  await Listing.findByIdAndDelete(req.params.id);
  req.flash("success", "Listing deleted!");
  res.redirect("/listings");
};

// MY LISTINGS
module.exports.myListings = async (req, res) => {
  const listings = await Listing.find({ author: req.user._id }).sort({ createdAt: -1 });
  res.render("listings/myListings", { listings });
};

