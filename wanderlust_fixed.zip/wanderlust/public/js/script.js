// Client-side JavaScript for Wanderlust

// Bootstrap tooltip initialization
document.addEventListener('DOMContentLoaded', function() {
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
});

// Auto-hide flash messages after 5 seconds
setTimeout(function() {
  var alerts = document.querySelectorAll('.alert');
  alerts.forEach(function(alert) {
    var bsAlert = new bootstrap.Alert(alert);
    bsAlert.close();
  });
}, 5000);


